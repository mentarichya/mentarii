const Header= document.querySelector("header");

window.addEventListener("scroll",function(){
  Header.classList.toggle("sticky,window.scroll > 200")
})